<?php
	include_once "setup.php";
	include_once "functions.php";
	session_start();

	
?>
<!DOCTYPE html>
<html>
<head>
	<title>Vote | LDK Elections System</title>
	<?php include_once "includes.php"; ?>
</head>
<body>

	<div class="container">
		<?php
			if(!empty($_SESSION['usename']) && !empty($_SESSION['pwds'])){
		echo "Welcome to visit";
		}else{
			//Here the user was not logged in
			?>
				<div class="col-sm-12">
					<h1>Welcome to The elections</h1>
					<p>Here you will find candidates loaded in their categories and vote</p>
					<p class="text-info"><i>You seem to be testing the system only, the voting will be facilitated by your head teacher or any other authority</i></p>

					<div class="">
						<?php $HTML->candVote(array('demo'), 'demo'); ?>
					</div>
				</div>
			<?php
		}
		?>

	</div>
	<?php 
	$HTML->VoteModal();
	include "sincludes.php"; ?>	

</body>
</html>