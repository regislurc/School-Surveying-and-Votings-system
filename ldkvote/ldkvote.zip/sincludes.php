<script type="text/javascript" src="js/jquery.min.js"></script>
<script type="text/javascript" src="js/tether.min.js"></script>
<script type="text/javascript" src="js/bs.min.js"></script>
<script type="text/javascript" src="js/script.js"></script>